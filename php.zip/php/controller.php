<?php

require '../vendor/autoload.php';

use Monolog\Logger;

$log = new Logger("Load controller");